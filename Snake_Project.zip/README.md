# Snake Kivy APK Project

This project contains the source code to build a Snake game APK using Buildozer.

Files included:
- main.py
- snake.kv
- buildozer.spec
- README.md

Build with:
    buildozer android debug
